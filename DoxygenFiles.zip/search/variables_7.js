var searchData=
[
  ['topo_0',['topo',['../struct_pilha.html#afcd152cd9c8d42972e6e7b28f221e0fa',1,'Pilha']]]
];
