var searchData=
[
  ['naipe_0',['naipe',['../struct__carta.html#aba763958bee1abb2961d0d2e82f8cdfb',1,'_carta']]],
  ['node_1',['node',['../struct__iterador.html#ab88cd70dad2e152cea983610f2a16e68',1,'_iterador']]],
  ['node_2',['Node',['../lista_8h.html#a96993f4b916f2bf4d596407b09467ae4',1,'lista.h']]]
];
