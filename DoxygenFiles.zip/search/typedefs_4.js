var searchData=
[
  ['t_0',['T',['../lista_8h.html#aedd0a1bf8b74c24ca0f41e4e6e3cd9b6',1,'lista.h']]]
];
