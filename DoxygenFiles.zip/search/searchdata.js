var indexSectionsWithContent =
{
  0: "_acdfijlmnprstv",
  1: "_p",
  2: "jlmprt",
  3: "acfilmpst",
  4: "acdlnpstv",
  5: "ilnpt",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

