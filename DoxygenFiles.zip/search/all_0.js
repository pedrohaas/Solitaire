var searchData=
[
  ['_5fcarta_0',['_carta',['../struct__carta.html',1,'']]],
  ['_5fiterador_1',['_iterador',['../struct__iterador.html',1,'']]],
  ['_5flista_2',['_lista',['../struct__lista.html',1,'']]],
  ['_5fnode_3',['_node',['../struct__node.html',1,'']]]
];
