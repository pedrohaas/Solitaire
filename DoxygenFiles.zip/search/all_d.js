var searchData=
[
  ['t_0',['T',['../lista_8h.html#aedd0a1bf8b74c24ca0f41e4e6e3cd9b6',1,'lista.h']]],
  ['teardown_1',['tearDown',['../teste_lista_8c.html#a9909011e5fea0c018842eec4d93d0662',1,'tearDown(void):&#160;testeLista.c'],['../teste_pilha_8c.html#a9909011e5fea0c018842eec4d93d0662',1,'tearDown(void):&#160;testePilha.c']]],
  ['teste0_2',['teste0',['../teste_lista_8c.html#a5d98b0091f69d53c510341af19a27ecf',1,'teste0():&#160;testeLista.c'],['../teste_pilha_8c.html#a5d98b0091f69d53c510341af19a27ecf',1,'teste0():&#160;testePilha.c']]],
  ['teste1_3',['teste1',['../teste_lista_8c.html#af6a96b5872e89f4f1caea1de6a224bdc',1,'teste1():&#160;testeLista.c'],['../teste_pilha_8c.html#af6a96b5872e89f4f1caea1de6a224bdc',1,'teste1():&#160;testePilha.c']]],
  ['teste10_4',['teste10',['../teste_lista_8c.html#aaf9d14b2f57f2375d476692ca6c0d5c9',1,'testeLista.c']]],
  ['teste11_5',['teste11',['../teste_lista_8c.html#aaa0f732614dd03b0245e7ad152f7dbc0',1,'testeLista.c']]],
  ['teste12_6',['teste12',['../teste_lista_8c.html#a789e8a177b32f8f031d07e4d2d382dac',1,'testeLista.c']]],
  ['teste2_7',['teste2',['../teste_lista_8c.html#a4ebabefc5008f4dfb64087e2b34f50bb',1,'teste2():&#160;testeLista.c'],['../teste_pilha_8c.html#a4ebabefc5008f4dfb64087e2b34f50bb',1,'teste2():&#160;testePilha.c']]],
  ['teste3_8',['teste3',['../teste_lista_8c.html#ac17b8cd2a38981dcd12e51fb82ff365d',1,'teste3():&#160;testeLista.c'],['../teste_pilha_8c.html#ac17b8cd2a38981dcd12e51fb82ff365d',1,'teste3():&#160;testePilha.c']]],
  ['teste4_9',['teste4',['../teste_lista_8c.html#a1251b8208db3f41105edbcb4a159876b',1,'teste4():&#160;testeLista.c'],['../teste_pilha_8c.html#a1251b8208db3f41105edbcb4a159876b',1,'teste4():&#160;testePilha.c']]],
  ['teste5_10',['teste5',['../teste_lista_8c.html#abb26d4412736ec445b5c60c0af9ba634',1,'teste5():&#160;testeLista.c'],['../teste_pilha_8c.html#abb26d4412736ec445b5c60c0af9ba634',1,'teste5():&#160;testePilha.c']]],
  ['teste6_11',['teste6',['../teste_lista_8c.html#a5246c490b43134662874a92af494c6f7',1,'teste6():&#160;testeLista.c'],['../teste_pilha_8c.html#a5246c490b43134662874a92af494c6f7',1,'teste6():&#160;testePilha.c']]],
  ['teste7_12',['teste7',['../teste_lista_8c.html#a65a8ca0cb69d954743f016668a557324',1,'testeLista.c']]],
  ['teste8_13',['teste8',['../teste_lista_8c.html#abedaee34cc3fd167fabc9cd64276d5e1',1,'testeLista.c']]],
  ['teste9_14',['teste9',['../teste_lista_8c.html#a4ed2fb201e3fa8ec4b66a4229d7f4c7c',1,'testeLista.c']]],
  ['testelista_2ec_15',['testeLista.c',['../teste_lista_8c.html',1,'']]],
  ['testepilha_2ec_16',['testePilha.c',['../teste_pilha_8c.html',1,'']]],
  ['topo_17',['topo',['../struct_pilha.html#afcd152cd9c8d42972e6e7b28f221e0fa',1,'Pilha::topo()'],['../pilha_8c.html#a03b97efb2a8dc5d39d9cd5ab98915aa8',1,'topo(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#a03b97efb2a8dc5d39d9cd5ab98915aa8',1,'topo(Pilha *stack):&#160;pilha.c']]]
];
