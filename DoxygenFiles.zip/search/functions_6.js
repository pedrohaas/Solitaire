var searchData=
[
  ['pilhadestroi_0',['pilhaDestroi',['../pilha_8c.html#a6c30fed1ebc27ab26e0ca1eec3a1e748',1,'pilhaDestroi(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#a6c30fed1ebc27ab26e0ca1eec3a1e748',1,'pilhaDestroi(Pilha *stack):&#160;pilha.c']]],
  ['pilhainicializa_1',['pilhaInicializa',['../pilha_8c.html#aed2643638757eb1f66e6b8d5d941673d',1,'pilhaInicializa(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#aed2643638757eb1f66e6b8d5d941673d',1,'pilhaInicializa(Pilha *stack):&#160;pilha.c']]],
  ['pilhaprinta_2',['pilhaPrinta',['../jogo_8c.html#a1f2e2f394f86b58e82e381e2f3951089',1,'jogo.c']]],
  ['pilhatopo_3',['pilhaTopo',['../pilha_8c.html#ad2ef315e54d727d6e1ea912dc2ff5037',1,'pilhaTopo(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#ad2ef315e54d727d6e1ea912dc2ff5037',1,'pilhaTopo(Pilha *stack):&#160;pilha.c']]],
  ['pilhavazia_4',['pilhaVazia',['../pilha_8c.html#a336893139dc82645e6615657b5f1fe6c',1,'pilhaVazia(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#a336893139dc82645e6615657b5f1fe6c',1,'pilhaVazia(Pilha *stack):&#160;pilha.c']]],
  ['pop_5',['pop',['../pilha_8c.html#a602b1841835d2b1360ff934523cc9d04',1,'pop(Pilha *stack):&#160;pilha.c'],['../pilha_8h.html#a602b1841835d2b1360ff934523cc9d04',1,'pop(Pilha *stack):&#160;pilha.c']]],
  ['preparamesa_6',['preparaMesa',['../jogo_8c.html#ac8e042732d8c319fe3f2cb7e86689e0d',1,'preparaMesa(Lista fileiras[], Pilha *virada, T cartas[]):&#160;jogo.c'],['../jogo_8h.html#ac8e042732d8c319fe3f2cb7e86689e0d',1,'preparaMesa(Lista fileiras[], Pilha *virada, T cartas[]):&#160;jogo.c']]],
  ['printabaralho_7',['printaBaralho',['../jogo_8c.html#a1c4b29030a39b2fda0a9e63185a7233a',1,'printaBaralho(T cartas[]):&#160;jogo.c'],['../jogo_8h.html#a1c4b29030a39b2fda0a9e63185a7233a',1,'printaBaralho(T cartas[]):&#160;jogo.c']]],
  ['printacarta_8',['printaCarta',['../jogo_8c.html#af43a470f6ed711758a6b37f87cd137d9',1,'printaCarta(T carta):&#160;jogo.c'],['../jogo_8h.html#af43a470f6ed711758a6b37f87cd137d9',1,'printaCarta(T carta):&#160;jogo.c']]],
  ['printamesa_9',['printaMesa',['../jogo_8c.html#a37731d2017d13792eedd2fe7fb6e1a5b',1,'printaMesa(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha pilhasF[]):&#160;jogo.c'],['../jogo_8h.html#a37731d2017d13792eedd2fe7fb6e1a5b',1,'printaMesa(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha pilhasF[]):&#160;jogo.c']]],
  ['printapilha_10',['printaPilha',['../jogo_8h.html#a8f80c74268e1d4d545311f645887adee',1,'jogo.h']]],
  ['printarfileira_11',['printarFileira',['../jogo_8c.html#a56648cc7c63efbe3d9e28e51045f3bbe',1,'printarFileira(Lista *fileira):&#160;jogo.c'],['../jogo_8h.html#ad4c7242a3f765ffd0e2bcf063ad526b2',1,'printarFileira(Lista *):&#160;jogo.c']]],
  ['push_12',['push',['../pilha_8c.html#a9afed314e376e3f62d23aed724831cba',1,'push(Pilha *stack, T item):&#160;pilha.c'],['../pilha_8h.html#a9afed314e376e3f62d23aed724831cba',1,'push(Pilha *stack, T item):&#160;pilha.c']]]
];
