var searchData=
[
  ['fimjogo_0',['fimJogo',['../jogo_8c.html#af60535b1ae0e209f1102a44f1328bba2',1,'fimJogo(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha finais[], Lista aux):&#160;jogo.c'],['../jogo_8h.html#a769ad8b00b3a2ab901add73f0b17bffc',1,'fimJogo(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha finais[]):&#160;jogo.h']]]
];
