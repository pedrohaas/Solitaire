var searchData=
[
  ['comparacor_0',['comparaCor',['../jogo_8c.html#aa05bac271d64bc4e0360171e046ddb0c',1,'comparaCor(T carta1, T carta2):&#160;jogo.c'],['../jogo_8h.html#aa05bac271d64bc4e0360171e046ddb0c',1,'comparaCor(T carta1, T carta2):&#160;jogo.c']]],
  ['comparadado_1',['comparaDado',['../lista_8c.html#a760294d1a4062ef536c223afb2ff6dbd',1,'comparaDado(T dado1, T dado2):&#160;lista.c'],['../lista_8h.html#a760294d1a4062ef536c223afb2ff6dbd',1,'comparaDado(T dado1, T dado2):&#160;lista.c']]],
  ['comparanaipe_2',['comparaNaipe',['../jogo_8c.html#add53ae8af738951a9065011996583035',1,'comparaNaipe(T carta1, T carta2):&#160;jogo.c'],['../jogo_8h.html#add53ae8af738951a9065011996583035',1,'comparaNaipe(T carta1, T carta2):&#160;jogo.c']]],
  ['criabaralho_3',['criaBaralho',['../jogo_8c.html#a244f26bdc056e0fee0e96909a96c61f1',1,'criaBaralho(T cartas[]):&#160;jogo.c'],['../jogo_8h.html#a244f26bdc056e0fee0e96909a96c61f1',1,'criaBaralho(T cartas[]):&#160;jogo.c']]]
];
