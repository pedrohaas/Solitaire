var searchData=
[
  ['aleatoriza_0',['aleatoriza',['../main_8c.html#a9f52b364ef492ba108092737b968a90b',1,'main.c']]]
];
