var searchData=
[
  ['main_0',['main',['../main_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;main.c'],['../teste_lista_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;testeLista.c'],['../teste_pilha_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;testePilha.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['mudavisibilidade_2',['mudaVisibilidade',['../jogo_8c.html#a20a99a720f3f5a62324cc90925f047f6',1,'mudaVisibilidade(Lista *fileira):&#160;jogo.c'],['../jogo_8h.html#a20a99a720f3f5a62324cc90925f047f6',1,'mudaVisibilidade(Lista *fileira):&#160;jogo.c']]]
];
