var searchData=
[
  ['pilha_2ec_0',['pilha.c',['../pilha_8c.html',1,'']]],
  ['pilha_2eh_1',['pilha.h',['../pilha_8h.html',1,'']]]
];
