var searchData=
[
  ['carta_0',['carta',['../struct_pilha.html#a7b8f48801e59e4e3dc08996d6a9b1b30',1,'Pilha']]]
];
