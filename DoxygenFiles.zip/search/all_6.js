var searchData=
[
  ['jogo_2ec_0',['jogo.c',['../jogo_8c.html',1,'']]],
  ['jogo_2eh_1',['jogo.h',['../jogo_8h.html',1,'']]]
];
