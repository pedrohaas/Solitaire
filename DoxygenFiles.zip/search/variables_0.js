var searchData=
[
  ['anterior_0',['anterior',['../struct__node.html#ac475813031b494727671e927146cefc3',1,'_node']]]
];
