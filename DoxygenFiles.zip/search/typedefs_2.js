var searchData=
[
  ['node_0',['Node',['../lista_8h.html#a96993f4b916f2bf4d596407b09467ae4',1,'lista.h']]]
];
