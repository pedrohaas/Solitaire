var searchData=
[
  ['projeto_20prático_20em_20grupo_20para_20a_20disciplina_20de_20estrutura_20de_20dados_0',['Projeto prático em grupo para a disciplina de Estrutura de Dados',['../md__r_e_a_d_m_e.html',1,'']]]
];
