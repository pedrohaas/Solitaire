var searchData=
[
  ['setup_0',['setUp',['../teste_lista_8c.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;testeLista.c'],['../teste_pilha_8c.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;testePilha.c']]],
  ['swap_1',['swap',['../main_8c.html#ab47e47e6c34002afcfb8a8a417b95587',1,'main.c']]]
];
