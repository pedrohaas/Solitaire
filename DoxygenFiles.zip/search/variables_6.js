var searchData=
[
  ['sentinela_0',['sentinela',['../struct__lista.html#a6b86d9b7174a0351f79805631a4f1785',1,'_lista']]]
];
